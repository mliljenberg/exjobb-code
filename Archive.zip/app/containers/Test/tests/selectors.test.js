// import { fromJS } from 'immutable';
// import { selectTestDomain } from '../selectors';

describe('selectTestDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
