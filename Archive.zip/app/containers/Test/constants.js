/*
 *
 * Test constants
 *
 */

export const SAVE_TO_DB = 'app/Test/SAVE_TO_DB';
export const SEND_TO_DB = 'app/Test/SEND_TO_DB';
