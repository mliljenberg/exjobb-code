/*
 *
 * Sus constants
 *
 */

export const DEFAULT_ACTION = 'app/Sus/DEFAULT_ACTION';
export const FINISH_TEST = 'app/Sus/FINISH_TEST';
