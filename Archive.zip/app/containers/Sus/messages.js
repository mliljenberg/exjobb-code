/*
 * Sus Messages
 *
 * This contains all the text for the Sus component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.Sus.header',
    defaultMessage: 'This is Sus container !',
  },
});
