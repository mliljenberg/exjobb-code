// import { fromJS } from 'immutable';
// import { selectSusDomain } from '../selectors';

describe('selectSusDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
