// import { fromJS } from 'immutable';
// import { selectBbcDomain } from '../selectors';

describe('selectBbcDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
