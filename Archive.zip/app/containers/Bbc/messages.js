/*
 * Bbc Messages
 *
 * This contains all the text for the Bbc component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.Bbc.header',
    defaultMessage: 'This is Bbc container !',
  },
});
