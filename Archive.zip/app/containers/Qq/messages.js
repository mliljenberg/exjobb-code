/*
 * Qq Messages
 *
 * This contains all the text for the Qq component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.Qq.header',
    defaultMessage: 'This is Qq container !',
  },
});
