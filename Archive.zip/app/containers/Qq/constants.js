/*
 *
 * Qq constants
 *
 */

export const DEFAULT_ACTION = 'app/Qq/DEFAULT_ACTION';
export const CLICK_ACTION = 'app/Qq/CLICK_ACTION';
export const FINISH_QUESTION_ACTION = 'app/Qq/FINISH_QUESTION_ACTION';
export const START_TIMER = 'START_TIMER';
export const RESET_TIMER = 'RESET_TIMER';
export const TICK = 'TICK';
export const ZH = 'ZH';
export const IMAGE_LOADED = 'IMAGE_LOADED';
export const INPUT_QUESTIONS = 'INPUT_QUESTIONS';
export const FINISH_TEST = 'FINISH_TEST';
