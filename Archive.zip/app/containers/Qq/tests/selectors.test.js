// import { fromJS } from 'immutable';
// import { selectQqDomain } from '../selectors';

describe('selectQqDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
