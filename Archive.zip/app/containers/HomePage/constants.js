/*
 *
 * Qq constants
 *
 */
export const START_TEST = 'START_TEST';
export const TEST_READY = 'TEST_READY';
