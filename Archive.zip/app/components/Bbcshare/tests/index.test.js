// import React from 'react';
// import { shallow } from 'enzyme';

// import Bbcshare from '../index';

describe('<Bbcshare />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
