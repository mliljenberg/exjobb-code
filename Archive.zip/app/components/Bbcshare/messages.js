/*
 * Bbcshare Messages
 *
 * This contains all the text for the Bbcshare component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Bbcshare.header',
    defaultMessage: 'This is the Bbcshare component !',
  },
});
