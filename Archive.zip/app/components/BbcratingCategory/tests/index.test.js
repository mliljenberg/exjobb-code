// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcratingCategory from '../index';

describe('<BbcratingCategory />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
