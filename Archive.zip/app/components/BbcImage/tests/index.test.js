// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcImage from '../index';

describe('<BbcImage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
