/*
 * BbcsmallCategory Messages
 *
 * This contains all the text for the BbcsmallCategory component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.BbcsmallCategory.header',
    defaultMessage: 'This is the BbcsmallCategory component !',
  },
});
