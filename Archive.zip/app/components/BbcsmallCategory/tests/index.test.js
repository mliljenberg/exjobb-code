// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcsmallCategory from '../index';

describe('<BbcsmallCategory />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
