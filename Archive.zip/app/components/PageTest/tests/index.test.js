// import React from 'react';
// import { shallow } from 'enzyme';

// import PageTest from '../index';

describe('<PageTest />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
