// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcCategory from '../index';

describe('<BbcCategory />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
