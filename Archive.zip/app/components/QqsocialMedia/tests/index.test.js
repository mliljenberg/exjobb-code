// import React from 'react';
// import { shallow } from 'enzyme';

// import QqsocialMedia from '../index';

describe('<QqsocialMedia />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
