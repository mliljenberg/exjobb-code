// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcmainNormalNews from '../index';

describe('<BbcmainNormalNews />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
