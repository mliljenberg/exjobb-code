/*
 * BbcmainNormalNews Messages
 *
 * This contains all the text for the BbcmainNormalNews component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.BbcmainNormalNews.header',
    defaultMessage: 'This is the BbcmainNormalNews component !',
  },
});
