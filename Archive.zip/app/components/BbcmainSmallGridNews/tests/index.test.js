// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcmainSmallGridNews from '../index';

describe('<BbcmainSmallGridNews />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
