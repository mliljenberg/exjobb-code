/*
 * BbcmainSmallGridNews Messages
 *
 * This contains all the text for the BbcmainSmallGridNews component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.BbcmainSmallGridNews.header',
    defaultMessage: 'This is the BbcmainSmallGridNews component !',
  },
});
