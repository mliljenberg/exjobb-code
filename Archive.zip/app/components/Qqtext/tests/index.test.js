// import React from 'react';
// import { shallow } from 'enzyme';

// import Qqtext from '../index';

describe('<Qqtext />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
