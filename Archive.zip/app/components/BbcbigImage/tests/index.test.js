// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcbigImage from '../index';

describe('<BbcbigImage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
