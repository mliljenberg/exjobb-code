/*
 * Bbcfooter Messages
 *
 * This contains all the text for the Bbcfooter component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Bbcfooter.header',
    defaultMessage: 'This is the Bbcfooter component !',
  },
});
