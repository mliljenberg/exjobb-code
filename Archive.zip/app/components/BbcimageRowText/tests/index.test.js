// import React from 'react';
// import { shallow } from 'enzyme';

// import BbcimageRowText from '../index';

describe('<BbcimageRowText />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
